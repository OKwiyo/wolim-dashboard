
const sheetID = "1ylRE6Q1Ena2N1CkOpHzT9sI3gfJTa1O2HEgHqYwzZ3o";

async function fetchData(sheetName) {
  const res = await fetch(`https://opensheet.vercel.app/${sheetID}/${sheetName}`);
  return await res.json();
}

async function loadDashboard() {
  const attendanceData = await fetchData("Attendance");
  const givingData = await fetchData("Giving");
  const engagementData = await fetchData("Engagement");

  // Attendance Summary
  const totalAttendance = attendanceData.reduce((sum, row) => sum + Number(row.Count || 0), 0);
  document.getElementById("total-attendance").innerText = `Total Attendance: ${totalAttendance}`;

  // Giving Summary
  const totalGiving = givingData.reduce((sum, row) => sum + Number(row.Amount || 0), 0);
  document.getElementById("total-giving").innerText = `Total Giving: $${totalGiving}`;

  // Engagement Summary
  const totalMinistries = engagementData.length;
  document.getElementById("engagement-summary").innerText = `Ministries: ${totalMinistries}`;

  // Charts
  const attendanceLabels = attendanceData.map(row => row.Date);
  const attendanceCounts = attendanceData.map(row => Number(row.Count || 0));
  new Chart(document.getElementById("attendanceChart"), {
    type: "line",
    data: {
      labels: attendanceLabels,
      datasets: [{ label: "Attendance", data: attendanceCounts, borderColor: "blue", fill: false }]
    }
  });

  const givingCategories = {};
  givingData.forEach(row => {
    const category = row.Category || "Other";
    const amount = Number(row.Amount || 0);
    givingCategories[category] = (givingCategories[category] || 0) + amount;
  });
  new Chart(document.getElementById("givingChart"), {
    type: "bar",
    data: {
      labels: Object.keys(givingCategories),
      datasets: [{ label: "Giving", data: Object.values(givingCategories), backgroundColor: "green" }]
    }
  });

  const engagementLabels = engagementData.map(row => row.Ministry);
  const engagementCounts = engagementData.map(row => Number(row["Number of Members"] || 0));
  new Chart(document.getElementById("engagementChart"), {
    type: "pie",
    data: {
      labels: engagementLabels,
      datasets: [{ label: "Ministry Engagement", data: engagementCounts }]
    }
  });
}

loadDashboard();
